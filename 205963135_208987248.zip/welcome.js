function welcome(){
    switchScreens("homeScreen");
    document.getElementById('accept').checked = false;
    manageSound(); 
    stopGame()
}